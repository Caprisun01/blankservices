const DemoBanner = () => {
  return (
    <div className="bg-accent text-accent-foreground text-center py-2 px-4 font-body text-sm font-semibold tracking-wide">
      ⚠️ THIS IS A DEMO WEBSITE — Not a real business. All content is for demonstration purposes only.
    </div>
  );
};

export default DemoBanner;
