import { Link } from "react-router-dom";

const Footer = () => {
  return (
    <footer className="bg-primary text-primary-foreground py-12">
      <div className="container mx-auto grid grid-cols-1 md:grid-cols-3 gap-8">
        <div>
          <h3 className="font-heading text-lg mb-3">
            IRONCLAD<span className="text-accent">.</span>BUILD
          </h3>
          <p className="font-body text-sm text-primary-foreground/70 leading-relaxed">
            Building excellence since 2005. Quality construction for commercial, residential, and industrial projects.
          </p>
          <p className="font-body text-xs text-accent mt-4 font-semibold">
            ⚠️ DEMO SITE — Not a real company
          </p>
        </div>
        <div>
          <h4 className="font-heading text-sm mb-3 uppercase tracking-wider">Quick Links</h4>
          <div className="flex flex-col gap-2">
            {[
              { to: "/", label: "Home" },
              { to: "/projects", label: "Projects" },
              { to: "/services", label: "Services" },
              { to: "/estimate", label: "Get Estimate" },
            ].map((link) => (
              <Link
                key={link.to}
                to={link.to}
                className="font-body text-sm text-primary-foreground/70 hover:text-accent transition-colors"
              >
                {link.label}
              </Link>
            ))}
          </div>
        </div>
        <div>
          <h4 className="font-heading text-sm mb-3 uppercase tracking-wider">Contact (Demo)</h4>
          <div className="font-body text-sm text-primary-foreground/70 space-y-1">
            <p>📍 123 Demo Street, Anytown, USA</p>
            <p>📞 (555) 123-4567</p>
            <p>✉️ demo@ironcladbuild.com</p>
          </div>
        </div>
      </div>
      <div className="container mx-auto mt-8 pt-6 border-t border-primary-foreground/10">
        <p className="font-body text-xs text-primary-foreground/50 text-center">
          © 2026 Ironclad Build — Demo Website. All rights reserved. This is not a real business.
        </p>
      </div>
    </footer>
  );
};

export default Footer;
