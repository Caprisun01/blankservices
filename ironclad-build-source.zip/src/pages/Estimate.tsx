import { useState } from "react";
import { toast } from "sonner";
import Layout from "@/components/Layout";

const projectTypes = ["Commercial", "Residential", "Renovation", "Industrial", "Infrastructure", "Other"];
const budgetRanges = ["Under $50,000", "$50,000 - $250,000", "$250,000 - $1M", "$1M - $5M", "$5M+", "Not sure"];

const Estimate = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    company: "",
    projectType: "",
    budget: "",
    timeline: "",
    description: "",
  });
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.projectType || !formData.description) {
      toast.error("Please fill in all required fields.");
      return;
    }
    setSubmitted(true);
    toast.success("Estimate request submitted! (Demo — no data is actually sent)");
  };

  if (submitted) {
    return (
      <Layout>
        <section className="py-20 bg-background">
          <div className="container mx-auto max-w-lg text-center">
            <div className="text-6xl mb-6">✅</div>
            <h1 className="font-heading text-3xl text-foreground mb-4">ESTIMATE REQUEST RECEIVED</h1>
            <p className="font-body text-muted-foreground mb-2">
              Thank you, {formData.name}! In a real scenario, our team would contact you within 24 hours.
            </p>
            <p className="font-body text-sm text-accent font-semibold mt-4">
              ⚠️ This is a demo — no data was actually submitted or stored.
            </p>
            <button
              onClick={() => { setSubmitted(false); setFormData({ name: "", email: "", phone: "", company: "", projectType: "", budget: "", timeline: "", description: "" }); }}
              className="mt-8 bg-accent text-accent-foreground px-6 py-3 font-body text-sm font-semibold uppercase tracking-wider rounded hover:opacity-90 transition-opacity"
            >
              Submit Another Request
            </button>
          </div>
        </section>
      </Layout>
    );
  }

  return (
    <Layout>
      <section className="py-16 bg-background">
        <div className="container mx-auto max-w-2xl">
          <h1 className="font-heading text-4xl text-foreground text-center mb-4">REQUEST AN ESTIMATE</h1>
          <p className="font-body text-muted-foreground text-center max-w-lg mx-auto mb-4">
            Fill out the form below and our team will get back to you with a free project estimate.
          </p>
          <p className="font-body text-sm text-accent text-center font-semibold mb-10">
            ⚠️ Demo form — no data is collected or stored
          </p>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="font-body text-sm font-semibold text-foreground mb-1 block">Name *</label>
                <input
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  className="w-full border border-border bg-card text-card-foreground rounded px-3 py-2 font-body text-sm focus:outline-none focus:ring-2 focus:ring-accent"
                  placeholder="John Smith"
                  maxLength={100}
                />
              </div>
              <div>
                <label className="font-body text-sm font-semibold text-foreground mb-1 block">Email *</label>
                <input
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleChange}
                  className="w-full border border-border bg-card text-card-foreground rounded px-3 py-2 font-body text-sm focus:outline-none focus:ring-2 focus:ring-accent"
                  placeholder="john@example.com"
                  maxLength={255}
                />
              </div>
              <div>
                <label className="font-body text-sm font-semibold text-foreground mb-1 block">Phone</label>
                <input
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  className="w-full border border-border bg-card text-card-foreground rounded px-3 py-2 font-body text-sm focus:outline-none focus:ring-2 focus:ring-accent"
                  placeholder="(555) 123-4567"
                  maxLength={20}
                />
              </div>
              <div>
                <label className="font-body text-sm font-semibold text-foreground mb-1 block">Company</label>
                <input
                  name="company"
                  value={formData.company}
                  onChange={handleChange}
                  className="w-full border border-border bg-card text-card-foreground rounded px-3 py-2 font-body text-sm focus:outline-none focus:ring-2 focus:ring-accent"
                  placeholder="Acme Corp"
                  maxLength={100}
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="font-body text-sm font-semibold text-foreground mb-1 block">Project Type *</label>
                <select
                  name="projectType"
                  value={formData.projectType}
                  onChange={handleChange}
                  className="w-full border border-border bg-card text-card-foreground rounded px-3 py-2 font-body text-sm focus:outline-none focus:ring-2 focus:ring-accent"
                >
                  <option value="">Select type...</option>
                  {projectTypes.map((t) => (
                    <option key={t} value={t}>{t}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="font-body text-sm font-semibold text-foreground mb-1 block">Budget Range</label>
                <select
                  name="budget"
                  value={formData.budget}
                  onChange={handleChange}
                  className="w-full border border-border bg-card text-card-foreground rounded px-3 py-2 font-body text-sm focus:outline-none focus:ring-2 focus:ring-accent"
                >
                  <option value="">Select budget...</option>
                  {budgetRanges.map((b) => (
                    <option key={b} value={b}>{b}</option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="font-body text-sm font-semibold text-foreground mb-1 block">Desired Timeline</label>
              <input
                name="timeline"
                value={formData.timeline}
                onChange={handleChange}
                className="w-full border border-border bg-card text-card-foreground rounded px-3 py-2 font-body text-sm focus:outline-none focus:ring-2 focus:ring-accent"
                placeholder="e.g., Start in 3 months, complete within 1 year"
                maxLength={200}
              />
            </div>

            <div>
              <label className="font-body text-sm font-semibold text-foreground mb-1 block">Project Description *</label>
              <textarea
                name="description"
                value={formData.description}
                onChange={handleChange}
                rows={5}
                className="w-full border border-border bg-card text-card-foreground rounded px-3 py-2 font-body text-sm focus:outline-none focus:ring-2 focus:ring-accent resize-none"
                placeholder="Tell us about your project — scope, location, special requirements..."
                maxLength={2000}
              />
            </div>

            <button
              type="submit"
              className="w-full bg-accent text-accent-foreground py-3 font-body font-semibold text-sm uppercase tracking-wider rounded hover:opacity-90 transition-opacity"
            >
              Submit Estimate Request
            </button>
          </form>
        </div>
      </section>
    </Layout>
  );
};

export default Estimate;
