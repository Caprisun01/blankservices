import { Link } from "react-router-dom";
import { ArrowRight, HardHat, Building2, Wrench, Shield } from "lucide-react";
import Layout from "@/components/Layout";
import heroImg from "@/assets/hero-construction.jpg";
import projectCommercial from "@/assets/project-commercial.jpg";
import projectResidential from "@/assets/project-residential.jpg";
import projectRenovation from "@/assets/project-renovation.jpg";
import projectIndustrial from "@/assets/project-industrial.jpg";

const featuredProjects = [
  { title: "Skyline Office Tower", category: "Commercial", image: projectCommercial },
  { title: "Maple Ridge Estates", category: "Residential", image: projectResidential },
  { title: "Heritage Kitchen Remodel", category: "Renovation", image: projectRenovation },
  { title: "Apex Distribution Center", category: "Industrial", image: projectIndustrial },
];

const stats = [
  { value: "250+", label: "Projects Completed" },
  { value: "18", label: "Years Experience" },
  { value: "98%", label: "Client Satisfaction" },
  { value: "50+", label: "Team Members" },
];

const services = [
  { icon: Building2, title: "Commercial", desc: "Office buildings, retail spaces, and mixed-use developments." },
  { icon: HardHat, title: "Residential", desc: "Custom homes, multi-family units, and luxury estates." },
  { icon: Wrench, title: "Renovation", desc: "Interior remodels, additions, and historic restorations." },
  { icon: Shield, title: "Industrial", desc: "Warehouses, factories, and heavy infrastructure projects." },
];

const Index = () => {
  return (
    <Layout>
      {/* Hero */}
      <section className="relative h-[70vh] min-h-[500px] flex items-center">
        <div className="absolute inset-0">
          <img src={heroImg} alt="Construction site at sunset" className="w-full h-full object-cover" width={1920} height={1080} />
          <div className="absolute inset-0 bg-primary/70" />
        </div>
        <div className="relative container mx-auto">
          <h1 className="font-heading text-4xl md:text-6xl text-primary-foreground max-w-2xl leading-tight animate-fade-in-up">
            WE BUILD THE<br />
            <span className="text-accent">FUTURE</span> YOU ENVISION
          </h1>
          <p className="font-body text-primary-foreground/80 mt-4 max-w-lg text-lg">
            Premium construction services for commercial, residential, and industrial projects. Quality craftsmanship, on time and on budget.
          </p>
          <div className="flex gap-4 mt-8">
            <Link
              to="/estimate"
              className="inline-flex items-center gap-2 bg-accent text-accent-foreground px-6 py-3 font-body font-semibold text-sm uppercase tracking-wider hover:opacity-90 transition-opacity rounded"
            >
              Get Free Estimate <ArrowRight size={16} />
            </Link>
            <Link
              to="/projects"
              className="inline-flex items-center gap-2 border border-primary-foreground/40 text-primary-foreground px-6 py-3 font-body font-semibold text-sm uppercase tracking-wider hover:bg-primary-foreground/10 transition-colors rounded"
            >
              View Projects
            </Link>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="bg-primary text-primary-foreground py-12">
        <div className="container mx-auto grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
          {stats.map((stat) => (
            <div key={stat.label}>
              <div className="font-heading text-3xl md:text-4xl text-accent">{stat.value}</div>
              <div className="font-body text-sm text-primary-foreground/70 mt-1 uppercase tracking-wider">{stat.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Services preview */}
      <section className="py-20 bg-background">
        <div className="container mx-auto">
          <h2 className="font-heading text-3xl text-foreground text-center mb-12">OUR SERVICES</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {services.map((svc) => (
              <div key={svc.title} className="bg-card border border-border p-6 rounded hover:shadow-lg transition-shadow">
                <svc.icon className="text-accent mb-4" size={32} />
                <h3 className="font-heading text-lg mb-2">{svc.title}</h3>
                <p className="font-body text-sm text-muted-foreground">{svc.desc}</p>
              </div>
            ))}
          </div>
          <div className="text-center mt-8">
            <Link to="/services" className="font-body text-sm text-accent font-semibold uppercase tracking-wider hover:underline">
              View All Services →
            </Link>
          </div>
        </div>
      </section>

      {/* Featured Projects */}
      <section className="py-20 bg-muted">
        <div className="container mx-auto">
          <h2 className="font-heading text-3xl text-foreground text-center mb-12">FEATURED PROJECTS</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {featuredProjects.map((project) => (
              <Link to="/projects" key={project.title} className="group relative overflow-hidden rounded">
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-500"
                  loading="lazy"
                  width={800}
                  height={600}
                />
                <div className="absolute inset-0 bg-primary/50 group-hover:bg-primary/60 transition-colors" />
                <div className="absolute bottom-4 left-4">
                  <span className="font-body text-xs text-accent uppercase tracking-wider font-semibold">{project.category}</span>
                  <h3 className="font-heading text-xl text-primary-foreground">{project.title}</h3>
                </div>
              </Link>
            ))}
          </div>
          <div className="text-center mt-8">
            <Link to="/projects" className="font-body text-sm text-accent font-semibold uppercase tracking-wider hover:underline">
              View All Projects →
            </Link>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-accent text-accent-foreground text-center">
        <div className="container mx-auto">
          <h2 className="font-heading text-3xl md:text-4xl mb-4">READY TO START YOUR PROJECT?</h2>
          <p className="font-body text-lg mb-8 opacity-90 max-w-lg mx-auto">
            Get a free, no-obligation estimate for your construction project today.
          </p>
          <Link
            to="/estimate"
            className="inline-flex items-center gap-2 bg-primary text-primary-foreground px-8 py-3 font-body font-semibold text-sm uppercase tracking-wider hover:opacity-90 transition-opacity rounded"
          >
            Request Estimate <ArrowRight size={16} />
          </Link>
        </div>
      </section>
    </Layout>
  );
};

export default Index;
