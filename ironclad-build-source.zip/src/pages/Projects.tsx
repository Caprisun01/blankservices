import { useState } from "react";
import Layout from "@/components/Layout";
import projectCommercial from "@/assets/project-commercial.jpg";
import projectResidential from "@/assets/project-residential.jpg";
import projectRenovation from "@/assets/project-renovation.jpg";
import projectIndustrial from "@/assets/project-industrial.jpg";
import projectInfrastructure from "@/assets/project-infrastructure.jpg";
import projectOffice from "@/assets/project-office.jpg";

const projects = [
  { title: "Skyline Office Tower", category: "Commercial", image: projectCommercial, location: "Downtown Metro", year: "2024", description: "A 12-story Class A office tower featuring curtain wall glazing and LEED Gold certification." },
  { title: "Maple Ridge Estates", category: "Residential", image: projectResidential, location: "Suburbia Heights", year: "2023", description: "Luxury residential community of 45 custom homes with modern architectural styling." },
  { title: "Heritage Kitchen Remodel", category: "Renovation", image: projectRenovation, location: "Historic District", year: "2024", description: "Full kitchen renovation preserving original crown molding with modern appliances." },
  { title: "Apex Distribution Center", category: "Industrial", image: projectIndustrial, location: "Industrial Park", year: "2023", description: "200,000 sq ft distribution facility with automated loading systems." },
  { title: "Riverside Bridge Expansion", category: "Infrastructure", image: projectInfrastructure, location: "River Valley", year: "2022", description: "Highway overpass expansion adding 4 lanes and improving traffic flow." },
  { title: "TechHub Office Renovation", category: "Commercial", image: projectOffice, location: "Innovation District", year: "2024", description: "Open-concept office conversion with exposed ceilings and collaborative workspaces." },
];

const categories = ["All", "Commercial", "Residential", "Renovation", "Industrial", "Infrastructure"];

const Projects = () => {
  const [filter, setFilter] = useState("All");
  const [selectedProject, setSelectedProject] = useState<typeof projects[0] | null>(null);

  const filtered = filter === "All" ? projects : projects.filter((p) => p.category === filter);

  return (
    <Layout>
      <section className="py-16 bg-background">
        <div className="container mx-auto">
          <h1 className="font-heading text-4xl text-foreground text-center mb-4">OUR PROJECTS</h1>
          <p className="font-body text-muted-foreground text-center max-w-lg mx-auto mb-10">
            Browse our portfolio of completed construction projects across all sectors.
          </p>

          {/* Filter */}
          <div className="flex flex-wrap justify-center gap-2 mb-10">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setFilter(cat)}
                className={`font-body text-xs uppercase tracking-wider px-4 py-2 rounded transition-colors ${
                  filter === cat
                    ? "bg-accent text-accent-foreground"
                    : "bg-muted text-muted-foreground hover:bg-muted/80"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filtered.map((project) => (
              <button
                key={project.title}
                onClick={() => setSelectedProject(project)}
                className="group text-left overflow-hidden rounded border border-border bg-card hover:shadow-lg transition-shadow"
              >
                <div className="overflow-hidden">
                  <img
                    src={project.image}
                    alt={project.title}
                    className="w-full h-56 object-cover group-hover:scale-105 transition-transform duration-500"
                    loading="lazy"
                    width={800}
                    height={600}
                  />
                </div>
                <div className="p-4">
                  <span className="font-body text-xs text-accent uppercase tracking-wider font-semibold">{project.category}</span>
                  <h3 className="font-heading text-lg text-card-foreground mt-1">{project.title}</h3>
                  <p className="font-body text-sm text-muted-foreground mt-1">{project.location} · {project.year}</p>
                </div>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Modal */}
      {selectedProject && (
        <div
          className="fixed inset-0 bg-primary/80 z-50 flex items-center justify-center p-4"
          onClick={() => setSelectedProject(null)}
        >
          <div
            className="bg-card rounded-lg max-w-2xl w-full overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <img src={selectedProject.image} alt={selectedProject.title} className="w-full h-72 object-cover" />
            <div className="p-6">
              <span className="font-body text-xs text-accent uppercase tracking-wider font-semibold">{selectedProject.category}</span>
              <h2 className="font-heading text-2xl text-card-foreground mt-1">{selectedProject.title}</h2>
              <p className="font-body text-sm text-muted-foreground mt-1">{selectedProject.location} · {selectedProject.year}</p>
              <p className="font-body text-card-foreground mt-4">{selectedProject.description}</p>
              <button
                onClick={() => setSelectedProject(null)}
                className="mt-6 bg-accent text-accent-foreground px-6 py-2 font-body text-sm font-semibold uppercase tracking-wider rounded hover:opacity-90 transition-opacity"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </Layout>
  );
};

export default Projects;
