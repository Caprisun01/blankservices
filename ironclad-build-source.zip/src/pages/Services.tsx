import { Link } from "react-router-dom";
import { Building2, HardHat, Wrench, Shield, Ruler, Truck } from "lucide-react";
import Layout from "@/components/Layout";

const services = [
  {
    icon: Building2,
    title: "Commercial Construction",
    description: "From office towers to retail centers, we deliver commercial spaces that meet the highest standards of quality and sustainability. Our team manages everything from pre-construction planning to final punch list.",
    features: ["Design-build services", "LEED certification support", "Tenant improvement", "Project management"],
  },
  {
    icon: HardHat,
    title: "Residential Construction",
    description: "We build dream homes. Whether it's a custom single-family residence or a multi-unit development, our craftsmen bring exceptional attention to detail and quality materials.",
    features: ["Custom home building", "Multi-family developments", "Luxury estates", "Energy-efficient homes"],
  },
  {
    icon: Wrench,
    title: "Renovation & Remodeling",
    description: "Transform your existing space with our renovation expertise. We handle kitchen and bath remodels, additions, historic restorations, and full building renovations.",
    features: ["Kitchen & bath remodels", "Whole-house renovations", "Historic restoration", "ADA compliance upgrades"],
  },
  {
    icon: Shield,
    title: "Industrial Construction",
    description: "Heavy-duty construction for warehouses, manufacturing plants, and distribution centers. We understand the unique requirements of industrial facilities.",
    features: ["Warehouses & logistics", "Manufacturing facilities", "Cold storage", "Clean rooms"],
  },
  {
    icon: Ruler,
    title: "Pre-Construction Services",
    description: "Our pre-construction team provides detailed cost estimates, constructability reviews, and value engineering to set your project up for success.",
    features: ["Cost estimation", "Value engineering", "Site assessment", "Permit coordination"],
  },
  {
    icon: Truck,
    title: "Infrastructure & Civil",
    description: "Roads, bridges, utilities, and site work. Our civil division handles the critical infrastructure that supports communities and commerce.",
    features: ["Road construction", "Bridge building", "Utility installation", "Site grading & prep"],
  },
];

const Services = () => {
  return (
    <Layout>
      <section className="py-16 bg-background">
        <div className="container mx-auto">
          <h1 className="font-heading text-4xl text-foreground text-center mb-4">OUR SERVICES</h1>
          <p className="font-body text-muted-foreground text-center max-w-lg mx-auto mb-14">
            Comprehensive construction services tailored to your project needs.
          </p>

          <div className="space-y-8">
            {services.map((svc, i) => (
              <div
                key={svc.title}
                className={`flex flex-col md:flex-row gap-6 items-start bg-card border border-border rounded p-6 md:p-8 ${
                  i % 2 === 1 ? "md:flex-row-reverse" : ""
                }`}
              >
                <div className="flex-shrink-0">
                  <div className="w-16 h-16 rounded bg-accent/10 flex items-center justify-center">
                    <svc.icon className="text-accent" size={32} />
                  </div>
                </div>
                <div className="flex-1">
                  <h2 className="font-heading text-xl text-card-foreground mb-2">{svc.title}</h2>
                  <p className="font-body text-muted-foreground mb-4">{svc.description}</p>
                  <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {svc.features.map((f) => (
                      <li key={f} className="font-body text-sm text-card-foreground flex items-center gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-accent flex-shrink-0" />
                        {f}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center mt-14">
            <Link
              to="/estimate"
              className="inline-flex items-center gap-2 bg-accent text-accent-foreground px-8 py-3 font-body font-semibold text-sm uppercase tracking-wider hover:opacity-90 transition-opacity rounded"
            >
              Get a Free Estimate
            </Link>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Services;
